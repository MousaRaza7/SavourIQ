import React from "react";
import Navbar from "../components/NavBar";

function Whiskey() {
  return (
    <div>
      <Navbar />
      <h1>Whiskey Page</h1>
      <p>Welcome to the Whiskey page!</p>
    </div>
  );
}

export default Whiskey;
