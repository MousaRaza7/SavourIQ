import React from "react";
import Navbar from "../components/NavBar";

function Contact() {
  return (
    <div>
      <Navbar />
      <h1>Contact Page</h1>
      <p>Welcome to the Contact page!</p>
    </div>
  );
}

export default Contact;
