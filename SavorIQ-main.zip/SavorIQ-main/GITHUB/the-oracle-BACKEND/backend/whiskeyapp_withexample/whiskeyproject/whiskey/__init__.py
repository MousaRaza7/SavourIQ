default_app_config = 'whiskeyapp.apps.WhiskeyappConfig'

